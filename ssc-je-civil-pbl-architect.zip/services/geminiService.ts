
import { GoogleGenAI, Type } from "@google/genai";

// Using gemini-3-flash-preview for maximum speed and token efficiency
const MODEL_NAME = 'gemini-3-flash-preview';

export interface SessionData {
  title: string;
  type: 'Theory' | 'Application';
  content: string;
}

export interface PBLDayResponse {
  sessions: SessionData[];
}

export async function generatePBLContent(
  day: number,
  topic: string,
  subject: string,
  milestone: string
): Promise<PBLDayResponse> {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    Generate a concise 1-day study module for SSC JE Civil Engineering. 
    Topic: ${topic}
    Subject: ${subject}
    City Milestone: ${milestone}
    
    Structure into 4 specific sessions:
    1. Theory: Core Fundamentals & Definitions.
    2. Theory: Vital IS Codes, Formulas & Standards (IS 456, 800 etc).
    3. Application: Step-by-step implementation in the city milestone.
    4. Application: 5 High-yield SSC JE Previous Year Questions with solutions.

    Guidelines: Be extremely concise. Use bullet points. Focus on data points and facts relevant to SSC JE. No fluff.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        temperature: 0.4, // Lower temperature for more factual, concise output
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sessions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING, description: "Session title" },
                  type: { type: Type.STRING, description: "Theory or Application" },
                  content: { type: Type.STRING, description: "Markdown formatted content" }
                },
                required: ["title", "type", "content"]
              }
            }
          },
          required: ["sessions"]
        }
      },
    });

    const result = JSON.parse(response.text || '{"sessions": []}');
    return result as PBLDayResponse;
  } catch (error) {
    console.error("Error generating content:", error);
    throw error;
  }
}
